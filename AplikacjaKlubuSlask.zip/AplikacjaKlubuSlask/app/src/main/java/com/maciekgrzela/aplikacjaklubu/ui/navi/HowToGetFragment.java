package com.maciekgrzela.aplikacjaklubu.ui.navi;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import com.maciekgrzela.aplikacjaklubu.R;

public class HowToGetFragment extends Fragment {

    private HowToGetViewModel howToGetViewModel;
    private WebView howToGetWebView;

    @SuppressLint("SetJavaScriptEnabled")
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        howToGetViewModel =
                ViewModelProviders.of(this).get(HowToGetViewModel.class);
        final View root = inflater.inflate(R.layout.fragment_how_to_get, container, false);

        howToGetWebView = root.findViewById(R.id.how_to_get_view);
        howToGetWebView.setWebViewClient(new WebViewClient());
        WebSettings howToGetWebSettings = howToGetWebView.getSettings();
        howToGetWebSettings.setJavaScriptEnabled(true);
        howToGetWebView.loadUrl(getString(R.string.how_to_get_url));

        howToGetViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(String news) {
            }
        });
        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }
}
